<h4 class="mb-4">Analytics Dashboard</h4>
<div class="alert alert-info">
    <i class="fas fa-info-circle me-2"></i>
    Analytics section coming soon...
</div> 