<h4 class="mb-4">Billing Reports</h4>
<div class="alert alert-info">
    <i class="fas fa-info-circle me-2"></i>
    Billing reports section coming soon...
</div> 