<h4 class="mb-4">Usage Reports</h4>
<div class="alert alert-info">
    <i class="fas fa-info-circle me-2"></i>
    Usage reports section coming soon...
</div> 