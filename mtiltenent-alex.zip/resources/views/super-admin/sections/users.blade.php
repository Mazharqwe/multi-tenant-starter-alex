<h4 class="mb-4">System Users</h4>
<div class="alert alert-info">
    <i class="fas fa-info-circle me-2"></i>
    System users section coming soon...
</div> 