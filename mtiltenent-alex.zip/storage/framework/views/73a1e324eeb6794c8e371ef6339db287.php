

<?php $__env->startSection('title', 'Dashboard Overview'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Overview Section -->
    <div id="overview" class="section active">
        <?php echo $__env->make('super-admin.sections.overview', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <!-- Tenants Section -->
    <div id="tenants" class="section">
        <?php echo $__env->make('super-admin.sections.tenants', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <!-- Add Tenant Section -->
    <div id="tenant-create" class="section">
        <?php echo $__env->make('super-admin.sections.tenant-create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <!-- System Settings Section -->
    <div id="settings" class="section">
        <?php echo $__env->make('super-admin.sections.settings', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <!-- Other sections -->
    <div id="analytics" class="section">
        <?php echo $__env->make('super-admin.sections.analytics', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div id="subscriptions" class="section">
        <?php echo $__env->make('super-admin.sections.subscriptions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div id="users" class="section">
        <?php echo $__env->make('super-admin.sections.users', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div id="logs" class="section">
        <?php echo $__env->make('super-admin.sections.logs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div id="reports" class="section">
        <?php echo $__env->make('super-admin.sections.reports', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div id="billing" class="section">
        <?php echo $__env->make('super-admin.sections.billing', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .section {
        display: none;
    }

    .section.active {
        display: block;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Initialize Charts
    document.addEventListener('DOMContentLoaded', function() {
        // Tenant Growth Chart
        const tenantGrowthCtx = document.getElementById('tenantGrowthChart');
        if (tenantGrowthCtx) {
            new Chart(tenantGrowthCtx.getContext('2d'), {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($chartData['labels'], 15, 512) ?>,
                    datasets: [{
                        label: 'New Tenants',
                        data: <?php echo json_encode($chartData['tenant_growth'], 15, 512) ?>,
                        borderColor: '#3498db',
                        backgroundColor: 'rgba(52, 152, 219, 0.1)',
                        tension: 0.4,
                        fill: true
                    }, {
                        label: 'Active Tenants',
                        data: <?php echo json_encode($chartData['active_tenants'], 15, 512) ?>,
                        borderColor: '#27ae60',
                        backgroundColor: 'rgba(39, 174, 96, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // Subscription Plans Chart
        const subscriptionCtx = document.getElementById('subscriptionChart');
        if (subscriptionCtx) {
            new Chart(subscriptionCtx.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: Object.keys(<?php echo json_encode($chartData['subscription_plans'], 15, 512) ?>),
                    datasets: [{
                        data: Object.values(<?php echo json_encode($chartData['subscription_plans'], 15, 512) ?>),
                        backgroundColor: ['#95a5a6', '#3498db', '#2c3e50', '#f39c12'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                        }
                    }
                }
            });
        }
    });

    // Simulate real-time updates
    setInterval(function() {
        updateDashboardStats();
    }, 30000); // Update every 30 seconds
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.super-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Raza Computer\Desktop\project\laravel\mtiltenent-alex\resources\views/super-admin/dashboard.blade.php ENDPATH**/ ?>