<h4 class="mb-4">System Logs</h4>
<div class="alert alert-info">
    <i class="fas fa-info-circle me-2"></i>
    System logs section coming soon...
</div> <?php /**PATH C:\Users\Raza Computer\Desktop\project\laravel\mtiltenent-alex\resources\views/super-admin/sections/logs.blade.php ENDPATH**/ ?>