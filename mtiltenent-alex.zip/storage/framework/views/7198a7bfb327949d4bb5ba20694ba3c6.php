<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['type' => 'primary', 'icon', 'number', 'label', 'id' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['type' => 'primary', 'icon', 'number', 'label', 'id' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="stat-card <?php echo e($type); ?>">
    <div class="d-flex align-items-center">
        <div class="stat-icon <?php echo e($type); ?>">
            <i class="<?php echo e($icon); ?>"></i>
        </div>
        <div class="ms-3">
            <h3 class="stat-number" <?php if($id): ?> id="<?php echo e($id); ?>" <?php endif; ?>><?php echo e($number); ?></h3>
            <p class="stat-label"><?php echo e($label); ?></p>
        </div>
    </div>
</div>

<style>
    .stat-card {
        background: white;
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        border-left: 4px solid;
        transition: all 0.3s;
        height: 100%;
    }

    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 30px rgba(0,0,0,0.12);
    }

    .stat-card.primary { border-left-color: var(--primary-color); }
    .stat-card.success { border-left-color: var(--success-color); }
    .stat-card.warning { border-left-color: var(--warning-color); }
    .stat-card.danger { border-left-color: var(--danger-color); }
    .stat-card.info { border-left-color: var(--info-color); }

    .stat-icon {
        width: 60px;
        height: 60px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        color: white;
    }

    .stat-icon.primary { background: var(--primary-color); }
    .stat-icon.success { background: var(--success-color); }
    .stat-icon.warning { background: var(--warning-color); }
    .stat-icon.danger { background: var(--danger-color); }
    .stat-icon.info { background: var(--info-color); }

    .stat-number {
        font-size: 2rem;
        font-weight: 700;
        color: var(--primary-color);
        margin: 0;
    }

    .stat-label {
        color: #6c757d;
        font-size: 0.9rem;
        margin: 0;
    }
</style> <?php /**PATH C:\Users\Raza Computer\Desktop\project\laravel\mtiltenent-alex\resources\views/super-admin/components/stat-card.blade.php ENDPATH**/ ?>