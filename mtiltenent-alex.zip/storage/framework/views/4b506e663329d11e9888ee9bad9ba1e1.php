<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['icon', 'color', 'title', 'description', 'time']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['icon', 'color', 'title', 'description', 'time']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="activity-item">
    <div class="activity-icon <?php echo e($color); ?> text-white">
        <i class="<?php echo e($icon); ?>"></i>
    </div>
    <div class="activity-content">
        <p class="activity-title"><?php echo e($title); ?></p>
        <p class="activity-desc"><?php echo e($description); ?></p>
    </div>
    <div class="activity-time"><?php echo e($time); ?></div>
</div>

<style>
    .activity-item {
        display: flex;
        align-items: center;
        padding: 1rem 0;
        border-bottom: 1px solid #e9ecef;
    }

    .activity-item:last-child {
        border-bottom: none;
    }

    .activity-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 1rem;
        font-size: 0.9rem;
    }

    .activity-content {
        flex: 1;
    }

    .activity-title {
        font-weight: 600;
        color: var(--primary-color);
        margin: 0 0 0.25rem;
    }

    .activity-desc {
        color: #6c757d;
        font-size: 0.9rem;
        margin: 0;
    }

    .activity-time {
        color: #adb5bd;
        font-size: 0.8rem;
    }
</style> <?php /**PATH C:\Users\Raza Computer\Desktop\project\laravel\mtiltenent-alex\resources\views/super-admin/components/activity-item.blade.php ENDPATH**/ ?>