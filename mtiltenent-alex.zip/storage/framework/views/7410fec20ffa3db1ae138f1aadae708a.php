<!-- Stats Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <?php if (isset($component)) { $__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65 = $attributes; } ?>
<?php $component = App\View\Components\SuperAdmin\StatCard::resolve(['type' => 'primary','icon' => 'fas fa-building','number' => number_format($stats['total_tenants']),'label' => 'Total Tenants','id' => 'totalTenants'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('super-admin.stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SuperAdmin\StatCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65)): ?>
<?php $attributes = $__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65; ?>
<?php unset($__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65)): ?>
<?php $component = $__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65; ?>
<?php unset($__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65); ?>
<?php endif; ?>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <?php if (isset($component)) { $__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65 = $attributes; } ?>
<?php $component = App\View\Components\SuperAdmin\StatCard::resolve(['type' => 'success','icon' => 'fas fa-check-circle','number' => number_format($stats['active_tenants']),'label' => 'Active Tenants','id' => 'activeTenants'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('super-admin.stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SuperAdmin\StatCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65)): ?>
<?php $attributes = $__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65; ?>
<?php unset($__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65)): ?>
<?php $component = $__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65; ?>
<?php unset($__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65); ?>
<?php endif; ?>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <?php if (isset($component)) { $__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65 = $attributes; } ?>
<?php $component = App\View\Components\SuperAdmin\StatCard::resolve(['type' => 'warning','icon' => 'fas fa-dollar-sign','number' => '$' . number_format($stats['monthly_revenue']),'label' => 'Monthly Revenue','id' => 'monthlyRevenue'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('super-admin.stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SuperAdmin\StatCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65)): ?>
<?php $attributes = $__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65; ?>
<?php unset($__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65)): ?>
<?php $component = $__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65; ?>
<?php unset($__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65); ?>
<?php endif; ?>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <?php if (isset($component)) { $__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65 = $attributes; } ?>
<?php $component = App\View\Components\SuperAdmin\StatCard::resolve(['type' => 'info','icon' => 'fas fa-users','number' => number_format($stats['total_users']),'label' => 'Total Users','id' => 'totalUsers'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('super-admin.stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SuperAdmin\StatCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65)): ?>
<?php $attributes = $__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65; ?>
<?php unset($__attributesOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65)): ?>
<?php $component = $__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65; ?>
<?php unset($__componentOriginalf6dfaf375cbc02a99c4d6b9c0ee38b65); ?>
<?php endif; ?>
    </div>
</div>

<div class="row">
    <!-- Quick Actions -->
    <div class="col-lg-4 mb-4">
        <div class="quick-actions">
            <h5 class="mb-4">Quick Actions</h5>
            <div class="row">
                <div class="col-6 mb-3">
                    <a href="<?php echo e(route('super-admin.tenants.create')); ?>" class="quick-action-btn">
                        <i class="fas fa-plus"></i>
                        <span>Add Tenant</span>
                    </a>
                </div>
                <div class="col-6 mb-3">
                    <a href="<?php echo e(route('super-admin.tenants.index')); ?>" class="quick-action-btn">
                        <i class="fas fa-building"></i>
                        <span>View Tenants</span>
                    </a>
                </div>
                <div class="col-6 mb-3">
                    <a href="#" class="quick-action-btn">
                        <i class="fas fa-chart-bar"></i>
                        <span>View Reports</span>
                    </a>
                </div>
                <div class="col-6 mb-3">
                    <a href="#" class="quick-action-btn">
                        <i class="fas fa-cogs"></i>
                        <span>Settings</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="col-lg-8 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Recent Activity</h5>
            </div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $recentActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if (isset($component)) { $__componentOriginal161f3f610456f9ceb14b85fa69e89bfc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal161f3f610456f9ceb14b85fa69e89bfc = $attributes; } ?>
<?php $component = App\View\Components\SuperAdmin\ActivityItem::resolve(['icon' => $activity['icon'],'color' => $activity['color'],'title' => $activity['title'],'description' => $activity['description'],'time' => $activity['time']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('super-admin.activity-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SuperAdmin\ActivityItem::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal161f3f610456f9ceb14b85fa69e89bfc)): ?>
<?php $attributes = $__attributesOriginal161f3f610456f9ceb14b85fa69e89bfc; ?>
<?php unset($__attributesOriginal161f3f610456f9ceb14b85fa69e89bfc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal161f3f610456f9ceb14b85fa69e89bfc)): ?>
<?php $component = $__componentOriginal161f3f610456f9ceb14b85fa69e89bfc; ?>
<?php unset($__componentOriginal161f3f610456f9ceb14b85fa69e89bfc); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-info-circle fa-2x mb-3"></i>
                        <p>No recent activity</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Charts Row -->
<div class="row">
    <div class="col-lg-8 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Tenant Growth</h5>
            </div>
            <div class="card-body">
                <canvas id="tenantGrowthChart" height="100"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-4 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Subscription Plans</h5>
            </div>
            <div class="card-body">
                <canvas id="subscriptionChart"></canvas>
            </div>
        </div>
    </div>
</div>

<style>
    .quick-actions {
        background: white;
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }

    .card {
        border: none;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }

    .card-header {
        background: white;
        border-bottom: 1px solid #e9ecef;
        padding: 1.5rem;
        border-radius: 12px 12px 0 0 !important;
    }
</style>
<?php /**PATH C:\Users\Raza Computer\Desktop\project\laravel\mtiltenent-alex\resources\views/super-admin/sections/overview.blade.php ENDPATH**/ ?>