

<?php $__env->startSection('title', 'Staff Management'); ?>
<?php $__env->startSection('page-title', 'Staff Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Staff Management</h2>
        <button class="btn btn-primary" onclick="openStaffModal()">
            <i class="bi bi-plus-circle me-2"></i>
            Add Staff Member
        </button>
    </div>

    <div class="row" id="staffContainer">
        <?php $__empty_1 = true; $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staffMember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-body text-center">
                    <div class="avatar bg-primary mx-auto mb-3" style="width: 80px; height: 80px; font-size: 2rem;">
                        <?php echo e(strtoupper(substr($staffMember->user->name, 0, 1))); ?>

                    </div>
                    
                    <h5 class="card-title mb-1"><?php echo e($staffMember->user->name); ?></h5>
                    <p class="text-muted mb-2"><?php echo e($staffMember->position); ?></p>
                    
                    <div class="mb-3">
                        <span class="badge <?php echo e($staffMember->is_active ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($staffMember->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                        <?php if($staffMember->specialization): ?>
                            <span class="badge bg-info"><?php echo e($staffMember->specialization); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="row text-center mb-3">
                        <div class="col-6">
                            <div class="border-end">
                                <h6 class="text-primary mb-1"><?php echo e($staffMember->appointments_count ?? 0); ?></h6>
                                <small class="text-muted">Appointments</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <h6 class="text-success mb-1"><?php echo e($staffMember->services_count ?? 0); ?></h6>
                            <small class="text-muted">Services</small>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-center gap-2">
                        <button class="btn btn-sm btn-outline-primary" onclick="editStaff(<?php echo e($staffMember->id); ?>)">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-info" onclick="viewStaffSchedule(<?php echo e($staffMember->id); ?>)">
                            <i class="bi bi-calendar"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteStaff(<?php echo e($staffMember->id); ?>)">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="text-center py-5">
                <i class="bi bi-person-badge display-1 text-muted"></i>
                <h4 class="mt-3">No Staff Members Found</h4>
                <p class="text-muted">Get started by adding your first staff member.</p>
                <button class="btn btn-primary" onclick="openStaffModal()">
                    <i class="bi bi-plus-circle me-2"></i>
                    Add Staff Member
                </button>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Staff Modal -->
<?php echo $__env->make('tenant.components.staff-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function openStaffModal() {
    $('#staffModal').modal('show');
}

function editStaff(staffId) {
    // Load staff data and show modal
    $('#staffModal').modal('show');
}

function viewStaffSchedule(staffId) {
    // View staff schedule logic
    window.location.href = `/staff/${staffId}/schedule`;
}

function deleteStaff(staffId) {
    if (confirm('Are you sure you want to delete this staff member?')) {
        // Delete staff logic
    }
}
</script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('tenant.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Raza Computer\Desktop\project\laravel\mtiltenent-alex\resources\views/tenant/pages/staff.blade.php ENDPATH**/ ?>