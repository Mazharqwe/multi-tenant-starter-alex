<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['tenant']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['tenant']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<tr>
    <td>
        <div class="d-flex align-items-center">
            <div class="tenant-avatar bg-primary"><?php echo e(strtoupper(substr($tenant->name, 0, 2))); ?></div>
            <div>
                <div class="fw-semibold"><?php echo e($tenant->name); ?></div>
                <small class="text-muted"><?php echo e($tenant->domains->first()->domain ?? 'No domain'); ?></small>
            </div>
        </div>
    </td>
    <td><span class="badge bg-success">Basic</span></td>
    <td><?php echo e(rand(5, 200)); ?></td>
    <td><?php echo e($tenant->created_at->format('M d, Y')); ?></td>
    <td>
        <span class="status-badge <?php echo e($tenant->is_active ? 'status-active' : 'status-inactive'); ?>">
            <?php echo e($tenant->is_active ? 'Active' : 'Inactive'); ?>

        </span>
    </td>
    <td>$99/mo</td>
    <td>
        <button class="btn btn-sm btn-outline-primary btn-action" onclick="viewTenant(<?php echo e($tenant->id); ?>)">
            <i class="fas fa-eye"></i>
        </button>
        <button class="btn btn-sm btn-outline-secondary btn-action" onclick="editTenant(<?php echo e($tenant->id); ?>)">
            <i class="fas fa-edit"></i>
        </button>
        <button class="btn btn-sm btn-outline-warning btn-action" onclick="toggleTenantStatus(<?php echo e($tenant->id); ?>)">
            <i class="fas fa-pause"></i>
        </button>
        <button class="btn btn-sm btn-outline-danger btn-action" onclick="deleteTenant(<?php echo e($tenant->id); ?>)">
            <i class="fas fa-trash"></i>
        </button>
    </td>
</tr>

<style>
    .tenant-avatar {
        width: 40px;
        height: 40px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        color: white;
        margin-right: 0.75rem;
    }

    .status-badge {
        padding: 0.375rem 0.75rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .status-active { background: #d4edda; color: #155724; }
    .status-inactive { background: #f8d7da; color: #721c24; }
    .status-suspended { background: #fff3cd; color: #856404; }
    .status-trial { background: #cce5ff; color: #004085; }

    .btn-action {
        padding: 0.375rem 0.75rem;
        margin: 0 0.125rem;
        border-radius: 6px;
        font-size: 0.8rem;
    }
</style> <?php /**PATH C:\Users\Raza Computer\Desktop\project\laravel\mtiltenent-alex\resources\views/super-admin/components/tenant-row.blade.php ENDPATH**/ ?>