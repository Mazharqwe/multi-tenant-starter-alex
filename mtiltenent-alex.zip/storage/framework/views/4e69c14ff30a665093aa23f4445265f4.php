<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['icon', 'text', 'onclick' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['icon', 'text', 'onclick' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<a href="#" class="quick-action-btn" <?php if($onclick): ?> onclick="<?php echo e($onclick); ?>" <?php endif; ?>>
    <i class="<?php echo e($icon); ?>"></i>
    <span><?php echo e($text); ?></span>
</a>

<style>
    .quick-action-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        padding: 1.5rem;
        border: 2px dashed #dee2e6;
        border-radius: 12px;
        text-decoration: none;
        color: #6c757d;
        transition: all 0.3s;
        height: 120px;
    }

    .quick-action-btn:hover {
        border-color: var(--secondary-color);
        color: var(--secondary-color);
        background: rgba(52, 152, 219, 0.05);
    }

    .quick-action-btn i {
        font-size: 2rem;
        margin-bottom: 0.5rem;
    }
</style> <?php /**PATH C:\Users\Raza Computer\Desktop\project\laravel\mtiltenent-alex\resources\views/super-admin/components/quick-action-btn.blade.php ENDPATH**/ ?>