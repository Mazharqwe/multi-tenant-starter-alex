<h4 class="mb-4">Analytics Dashboard</h4>
<div class="alert alert-info">
    <i class="fas fa-info-circle me-2"></i>
    Analytics section coming soon...
</div> <?php /**PATH C:\Users\Raza Computer\Desktop\project\laravel\mtiltenent-alex\resources\views/super-admin/sections/analytics.blade.php ENDPATH**/ ?>