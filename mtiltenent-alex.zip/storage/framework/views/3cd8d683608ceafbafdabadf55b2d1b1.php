

<?php $__env->startSection('title', 'Appointments Management'); ?>
<?php $__env->startSection('page-title', 'Appointments Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Appointments Management</h2>
        <div class="d-flex gap-2">
            <button class="btn btn-outline-secondary">
                <i class="bi bi-calendar me-2"></i>
                Calendar View
            </button>
            <button class="btn btn-primary" onclick="openAppointmentModal()">
                <i class="bi bi-plus-circle me-2"></i>
                Schedule Appointment
            </button>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title text-primary"><?php echo e($stats['total_appointments']); ?></h5>
                    <p class="card-text">Total Appointments</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title text-success"><?php echo e($stats['confirmed_appointments'] ?? 0); ?></h5>
                    <p class="card-text">Confirmed</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title text-warning"><?php echo e($stats['pending_appointments']); ?></h5>
                    <p class="card-text">Pending</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title text-danger"><?php echo e($stats['cancelled_appointments'] ?? 0); ?></h5>
                    <p class="card-text">Cancelled</p>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="row align-items-center">
                <div class="col">
                    <h5 class="mb-0">All Appointments</h5>
                </div>
                <div class="col-auto">
                    <div class="d-flex gap-2">
                        <select class="form-select form-select-sm" id="appointmentStatusFilter">
                            <option value="">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="confirmed">Confirmed</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                        <div class="input-group">
                            <input type="text" class="form-control form-control-sm" placeholder="Search..." id="appointmentSearch">
                            <button class="btn btn-outline-secondary btn-sm" onclick="searchAppointments()">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Customer</th>
                            <th>Service</th>
                            <th>Staff</th>
                            <th>Date & Time</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="appointmentsTableBody">
                        <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar bg-primary me-2">
                                        <?php echo e(strtoupper(substr($appointment->customer->name, 0, 1))); ?>

                                    </div>
                                    <div>
                                        <div class="fw-bold"><?php echo e($appointment->customer->name); ?></div>
                                        <small class="text-muted"><?php echo e($appointment->customer->email); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="fw-bold"><?php echo e($appointment->service->name); ?></div>
                                <small class="text-muted">$<?php echo e($appointment->service->price); ?></small>
                            </td>
                            <td><?php echo e($appointment->staff->user->name); ?></td>
                            <td>
                                <div><?php echo e($appointment->appointment_date->format('M j, Y')); ?></div>
                                <small class="text-muted"><?php echo e($appointment->appointment_time); ?></small>
                            </td>
                            <td><?php echo e($appointment->service->duration); ?> min</td>
                            <td>
                                <?php
                                    $statusColors = [
                                        'pending' => 'bg-warning',
                                        'confirmed' => 'bg-success',
                                        'cancelled' => 'bg-danger',
                                        'completed' => 'bg-secondary'
                                    ];
                                    $statusColor = $statusColors[$appointment->status] ?? 'bg-secondary';
                                ?>
                                <span class="badge <?php echo e($statusColor); ?>"><?php echo e(ucfirst($appointment->status)); ?></span>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-outline-primary" onclick="editAppointment(<?php echo e($appointment->id); ?>)">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn btn-outline-success" onclick="confirmAppointment(<?php echo e($appointment->id); ?>)">
                                        <i class="bi bi-check"></i>
                                    </button>
                                    <button class="btn btn-outline-danger" onclick="cancelAppointment(<?php echo e($appointment->id); ?>)">
                                        <i class="bi bi-x"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted">No appointments found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Appointment Modal -->
<?php echo $__env->make('tenant.components.appointment-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function openAppointmentModal() {
    $('#appointmentModal').modal('show');
}

function editAppointment(appointmentId) {
    // Load appointment data and show modal
    $('#appointmentModal').modal('show');
}

function confirmAppointment(appointmentId) {
    if (confirm('Confirm this appointment?')) {
        // Confirm appointment logic
    }
}

function cancelAppointment(appointmentId) {
    if (confirm('Cancel this appointment?')) {
        // Cancel appointment logic
    }
}

function searchAppointments() {
    const searchTerm = $('#appointmentSearch').val();
    // Implement search logic
}
</script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('tenant.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Raza Computer\Desktop\project\laravel\mtiltenent-alex\resources\views/tenant/pages/appointments.blade.php ENDPATH**/ ?>